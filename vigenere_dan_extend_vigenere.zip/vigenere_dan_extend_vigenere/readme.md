# Tugas Kecil 1 IF4020
## Kriptografi Klasik
Implementasi
- Vigenere Standar (26 huruf)
- Full Vigenere Cipher
- Auto-key Vigenere Cipher
- Extended Vigenere Cipher (256 karakter ASCII)
- Playfair Cipher (26 huruf)
- Affine Cipher (26 huruf)
- - Bonus: Hill Cipher/Enigma Cipher
## Author
Fransiskus Febryan Suryawan 13519124
Melita 13519063